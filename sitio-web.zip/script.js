const WHATSAPP_NUMBER = '525510698958';

document.getElementById('year').textContent = new Date().getFullYear();

// Mobile nav toggle
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});

// Catalog "Solicitar cotización" buttons scroll to form and preselect type
document.querySelectorAll('.card-link').forEach(btn => {
  btn.addEventListener('click', () => {
    const tipo = btn.dataset.tipo;
    const select = document.getElementById('tipo');
    if (tipo && select) {
      [...select.options].forEach(opt => {
        if (opt.value === tipo) select.value = tipo;
      });
    }
    document.getElementById('cotizar').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('nombre').focus({ preventScroll: true });
  });
});

// Quote form -> build WhatsApp message
const form = document.getElementById('quoteForm');
const toast = document.getElementById('toast');

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const nombre = form.nombre.value.trim();
  const telefono = form.telefono.value.trim();
  const tipo = form.tipo.value;
  const cantidad = form.cantidad.value.trim();
  const dias = form.dias.value.trim();
  const zona = form.zona.value.trim();
  const comentarios = form.comentarios.value.trim();

  if (!nombre || !telefono || !tipo) {
    showToast('Por favor completa nombre, teléfono y tipo de andamio.');
    return;
  }

  const lines = [
    'Hola, quiero cotizar una renta de andamios:',
    `• Nombre: ${nombre}`,
    `• Teléfono: ${telefono}`,
    `• Tipo de andamio: ${tipo}`,
  ];
  if (cantidad) lines.push(`• Cantidad de cuerpos: ${cantidad}`);
  if (dias) lines.push(`• Días de renta: ${dias}`);
  if (zona) lines.push(`• Zona de entrega: ${zona}`);
  if (comentarios) lines.push(`• Comentarios: ${comentarios}`);

  const message = encodeURIComponent(lines.join('\n'));
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;
  window.open(url, '_blank', 'noopener');
});
